
if (!localStorage.getItem("balance")) localStorage.setItem("balance", "1000");

function notify(msg, type = 'info') {
  alert(msg); 
}

function updateUI() {
  const bal = localStorage.getItem("balance");
  const el = document.getElementById("wallet-bal");
  if (el) el.innerText = `$${bal}`;
}

function claimDaily() {
  const lastClaim = localStorage.getItem("lastClaim");
  const now = new Date().getTime();
  
  if (lastClaim && now - lastClaim < 86400000) {
    return notify("Come back tomorrow for more!");
  }
  
  let bal = parseInt(localStorage.getItem("balance"));
  localStorage.setItem("balance", bal + 500);
  localStorage.setItem("lastClaim", now);
  notify("Daily reward of $500 claimed!", "success");
  updateUI();
}

function register() {
  const u = document.getElementById("user").value;
  const p = document.getElementById("pass").value;
  if(!u || !p) return notify("Fields cannot be empty");
  localStorage.setItem("user", u);
  localStorage.setItem("pass", p);
  notify("Registered! Login to play.");
  location.href = "login.html";
}

function login() {
  const u = document.getElementById("user").value;
  const p = document.getElementById("pass").value;
  if(u === localStorage.getItem("user") && p === localStorage.getItem("pass")) {
    localStorage.setItem("loggedIn", "true");
    location.href = "dashboard.html";
  } else {
    notify("Invalid login credentials");
  }
}