if(localStorage.getItem("loggedIn")!=="true"){
  location.href="../auth/login.html";
}
